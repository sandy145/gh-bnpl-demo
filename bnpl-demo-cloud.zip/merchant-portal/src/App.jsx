import React from 'react';
export default function App() {
  return <h1>BNPL Merchant Portal</h1>;
}